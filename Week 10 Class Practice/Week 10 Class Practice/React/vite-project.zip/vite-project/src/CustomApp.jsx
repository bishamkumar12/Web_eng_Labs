import { Circle } from "./Cricle";
const CustomApp = () => {
  return (
    <>
      <Circle />
      <Circle />
      <Circle />
      <Circle />
      <Circle />

      <h1>This is the heading from Custom App</h1>
      <h2>This is heading two</h2>
    </>
  );
};
export default CustomApp;
